function setContourfAlpha(contour_h,alpha)
% setContourfAlpha(contour_h,alpha)
% Plot utilty to set transparency of contour plots
% Inputs:
% contour_h: handle to contour plot
% alpha: transparency level

%%
val=round(alpha*255);

hFills = contour_h.FacePrims;  % array of TriangleStrip objects
[hFills.ColorType] = deal('truecoloralpha');  % default = 'truecolor'
for idx = 1 : numel(hFills)
    hFills(idx).ColorData(4) = val;   % default=255
end
end

