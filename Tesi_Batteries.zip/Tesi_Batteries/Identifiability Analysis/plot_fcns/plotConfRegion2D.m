function plotConfRegion2D(GridStruct,ParStruct,idxA,idxB,CHIsqDiff,alfa,satPlot,colorscale)
% plotConfRegion2D(GridStruct,ParStruct,idxA,idxB,CHIsqDiff,alfa,satPlot,colorscale)
% Plot utility for 2-d confidence regions (see @nonlinConfRegion2D)
% Inputs:
% GridStruct: struct for param grid, see @nonlinConfRegion2D
% ParStruct: struct for param info, see @nonlinConfRegion2D
% idxA: scalar, index of first parameter to be examined, see @nonlinConfRegion2D
% idxB: scalar, index of second parameter to be examined, see @nonlinConfRegion2D
% CHIsqDiff: matrix, difference of chi-squared values between test points
% and ground truth point, see @nonlinConfRegion2D
% alfa: scalar, significance level
% satPlot: bool, if true/1 upper saturate CHIsqDiff for plot purposes only
% colorscale: string for Matlab colorscale selection

%%

LogThetaStar=ParStruct.LogThetaStar;

%% interpolate nans if not on boundary

CHIsqDiff=fillmissing(CHIsqDiff,'movmean',[1 1]);
%% compute boundary of confidence region and min
CHIsqConfBound=chi2inv(1-alfa,2);

minChisqDiff=min(min(CHIsqDiff));
[idxMin_a,idxMin_b]=find(CHIsqDiff==minChisqDiff);

CHIsqDiff=CHIsqDiff-minChisqDiff;
%% saturate maximum values
CHIsqDiff_full=CHIsqDiff;

if satPlot ==1
    if minChisqDiff<CHIsqConfBound
        satValup=40*CHIsqConfBound;   
    else
        satValup=60*minChisqDiff;
    end
    CHIsqDiff(CHIsqDiff>satValup)=satValup;
end

%%
contourf(GridStruct.A,GridStruct.B,CHIsqDiff)
hold on
plot(GridStruct.A(idxMin_a,idxMin_b),GridStruct.B(idxMin_a,idxMin_b),'oc','LineWidth',2,'markersize',5)
plot(LogThetaStar(idxA),LogThetaStar(idxB),'*r','LineWidth',2,'markersize',11)
contour(GridStruct.A,GridStruct.B,CHIsqDiff_full,[CHIsqConfBound CHIsqConfBound],':r','LineWidth',2)
hold off

%% 
xlabel(['$Log(',ParStruct.ThetaName{idxA},')\;',ParStruct.ThetaType{idxA},'$'],'Interpreter','Latex')
ylabel(['$Log(',ParStruct.ThetaName{idxB},')\;',ParStruct.ThetaType{idxB},'$'],'Interpreter','Latex')

cbar=colorbar;
cbar.Label.String='$\chi^2 (\theta) - \chi^2(\theta^\star)$';
cbar.Label.Interpreter='Latex';

colormap('pink');
set(gca,'ColorScale',colorscale)

end

