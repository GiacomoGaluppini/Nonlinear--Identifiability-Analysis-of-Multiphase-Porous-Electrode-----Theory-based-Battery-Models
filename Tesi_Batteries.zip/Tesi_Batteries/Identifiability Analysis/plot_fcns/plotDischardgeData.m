function plotDischardgeData(V,I,time,Vcutoff,Cdisch)
% plotDischardgeData(V,I,time,Vcutoff,Cdisch)
% Plot utility for discharge data
% Inputs:
% V:  array, voltage 
% I:  array, C rate 
% time:  array, time 
% Vcutoff:  scalar, voltage cutoff 
% Cdisch:  scalar, C rate discharge value

%%

h(1)=subplot(2,1,1);
plot(time,V,'-b','LineWidth',2)
if ~ isempty(Vcutoff)
hold on
plot([time(1) time(end)],[Vcutoff Vcutoff],'-.g','LineWidth',1.5)
hold off
end
grid on
legend('V','V_{cutoff}')
xlabel('t [s]')
ylabel('V [V]')


h(2)=subplot(2,1,2);
plot(time,I,'-r','LineWidth',2)
if ~ isempty(Cdisch)
hold on
plot([time(1) time(end)],[Cdisch Cdisch],'-.g','LineWidth',1.5)
hold off
end
grid on
legend('I','I_{disch}')
xlabel('t [s]')
ylabel('I [C_{ratio}]')

linkaxes(h,'x');
%reset current axis to subplot 1
subplot(2,1,1)
end

