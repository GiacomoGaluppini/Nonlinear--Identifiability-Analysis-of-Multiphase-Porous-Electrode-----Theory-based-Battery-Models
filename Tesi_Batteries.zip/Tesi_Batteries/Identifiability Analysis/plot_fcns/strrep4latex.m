function [str_out] = strrep4latex(name_in,type_in)

if strcmp(type_in,'M')
    type_out='e';
else
    type_out=lower(type_in);
end

switch lower(name_in)
    case 'omega_a'
        name_out='\Omega_a';
    case 'omega_b'
        name_out='\Omega_b';
    case 'kappa'
        name_out='\kappa';
    case 'k0'
        name_out='k_0';
    case 'rfilm'
        name_out='R_{film}';
    case 'dp'
        name_out='D_{\!+}';
    case 'dm'
        name_out='D_{\!-}';
    otherwise
        name_out=name_in;
end

str_out=['$',name_out,'^{',type_out,'}$'];

end


