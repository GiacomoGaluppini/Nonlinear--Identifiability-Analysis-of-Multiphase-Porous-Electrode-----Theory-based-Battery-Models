function comparePlot(time,Y,Yhat)
% comparePlot(time,Y,Yhat)
% Plot utility, plots model-data comparison
% Inputs:
% time: array, voltage data timestamps
% Y: array, voltage data 
% Yhat: array, model predicted discharge voltage
%%

plot(time,Y,'-xb')
hold on
plot(time,Yhat,'or')
hold off
grid on
xlabel('t')
ylabel('Y')
legend('Y','Y_{hat}')

end

