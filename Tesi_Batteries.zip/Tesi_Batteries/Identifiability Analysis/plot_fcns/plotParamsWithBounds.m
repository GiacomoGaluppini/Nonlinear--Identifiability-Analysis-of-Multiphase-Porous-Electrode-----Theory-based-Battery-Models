function plotParamsWithBounds(Params,LB,UB,varargin)
% Plot utility, plots param values and param bounds
% Inputs:
% Params: array, parameter values
% LB: array, parameter lower bounds
% UB: array, parameter upper bounds
% Optional Inputs:
% ParamsNames: cell array of strings, as required for XTickLabels, paramter names

%%
styles={'or','xb','xg','xy','xm'};

if nargin==4
    ParamsNames=varargin{1};
end

if ~iscell(Params)
    Params={Params};
end

%%
hold on
for i=1:length(LB)
    plot([i i],[LB(i) UB(i)],'xk')
    plot([i i],[LB(i) UB(i)],'--k')
end

for i=1:length(Params)
    plot([1:length(Params{i})],Params{i},styles{i})
end

hold off
grid on
ax=gca;
ax.XTick=[1:length(Params{1})];
ax.XLim=[0 length(Params{1})+1];
if nargin==4
    ax.XTickLabel=ParamsNames;
    ax.XTickLabelRotation=60;
end
end

