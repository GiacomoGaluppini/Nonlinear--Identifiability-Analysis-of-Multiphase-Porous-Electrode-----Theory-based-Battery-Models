function plotConfRegion3D(GridStruct,ParStruct,idxA,idxB,idxC,CHIsqDiff,alfa,zslicesIdx,satPlot)
% plotConfRegion2D(GridStruct,ParStruct,idxA,idxB,CHIsqDiff,alfa,satPlot,colorscale)
% Plot utility for 3-d confidence regions (see @nonlinConfRegion3D)
% Inputs:
% GridStruct: struct for param grid, see @nonlinConfRegion3D
% ParStruct: struct for param info, see @nonlinConfRegion3D
% idxA: scalar, index of first parameter to be examined, see @nonlinConfRegion3D
% idxB: scalar, index of second parameter to be examined, see @nonlinConfRegion3D
% idxC: scalar, index of third parameter to be examined, see @nonlinConfRegion3D
% CHIsqDiff: matrix, difference of chi-squared values between test points
% and ground truth point, see @nonlinConfRegion3D
% alfa: scalar, significance level
% zslicesIdx: array, indces of z-slices to plot
% satPlot: bool, if true/1 upper saturate CHIsqDiff for plot purposes only

%%
LogThetaStar=ParStruct.LogThetaStar;
colormap('pink');

%% interpolate nans if not on boundary

CHIsqDiff=fillmissing(CHIsqDiff,'movmean',[1 1]);
%% compute boundary of confidence region and min
CHIsqConfBound=chi2inv(1-alfa,3);

minChisqDiff=min(min(min(CHIsqDiff)));
[idxMin_a,idxMin_b,idxMin_c] = ind2sub(size(CHIsqDiff),find(CHIsqDiff == minChisqDiff));

CHIsqDiff=CHIsqDiff-minChisqDiff;
%% saturate maximum values
CHIsqDiff_full=CHIsqDiff;

if satPlot ==1
    if minChisqDiff<CHIsqConfBound
        satValup=10*CHIsqConfBound;   
    else
        satValup=20*minChisqDiff;
    end
    CHIsqDiff(CHIsqDiff>satValup)=satValup;
end
%% plot slices
hold on
zslices=squeeze(GridStruct.C(1,1,zslicesIdx));
sh=contourslice(GridStruct.A,GridStruct.B,GridStruct.C,CHIsqDiff,[],[],zslices,[CHIsqConfBound CHIsqConfBound]);
 
for i=1:length(sh)
sh(i).LineWidth=2;
sh(i).LineStyle='--';
sh(i).EdgeColor='r';
end


%% plot confidence bounds on each slide

for k=1:length(zslicesIdx)
    
    if min(min(CHIsqDiff(:,:,zslicesIdx(k))))==max(max(CHIsqDiff(:,:,zslicesIdx(k))))
        CHIsqDiff(1,1,zslicesIdx(k))=CHIsqDiff(1,1,zslicesIdx(k))*(1.000001);
    end
    
    [~,h(k)]=contourf(GridStruct.A(:,:,zslicesIdx(k)),GridStruct.B(:,:,zslicesIdx(k)),CHIsqDiff(:,:,zslicesIdx(k)));
    h(k).ContourZLevel = zslices(k);
end

%% plot confidence bounds as isosurfaces

ih=patch(isosurface(GridStruct.A,GridStruct.B,GridStruct.C,CHIsqDiff,CHIsqConfBound));

ih.FaceColor='r';
ih.FaceAlpha=0.4;
ih.EdgeColor='k';
ih.EdgeAlpha=0.4;
%% plot Star and Best parameter
plot3(LogThetaStar(idxA),LogThetaStar(idxB),LogThetaStar(idxC),'*r','LineWidth',2,'markersize',15)
plot3(GridStruct.A(idxMin_a,idxMin_b,idxMin_c),GridStruct.B(idxMin_a,idxMin_b,idxMin_c),GridStruct.C(idxMin_a,idxMin_b,idxMin_c),'oc','LineWidth',5,'markersize',5)

%%
hold off

xlabel(['$Log(',ParStruct.ThetaName{idxA},')-',ParStruct.ThetaType{idxA},'$'],'Interpreter','Latex')
ylabel(['$Log(',ParStruct.ThetaName{idxB},')-',ParStruct.ThetaType{idxB},'$'],'Interpreter','Latex')
zlabel(['$Log(',ParStruct.ThetaName{idxC},')-',ParStruct.ThetaType{idxC},'$'],'Interpreter','Latex')

cbar=colorbar;
cbar.Label.String='$\chi^2 (\theta) - \chi^2(\theta^\star)$';
cbar.Label.Interpreter='Latex';

%% set ax limits
ax=gca;
ax.ZLim=[min(GridStruct.C(1,1,:))  max(GridStruct.C(1,1,:))];
ax.View=[-34.0544   12.7347];
% set(ax,'ColorScale','log')
grid on

%% set transparency of slices

pause(0.1)% won't apply alpha otherwise... ??
for k=1:length(zslicesIdx)
    setContourfAlpha(h(k),0.55)
end

end

