function  plotParamVariance(Vtheta,ThetaName,ThetaType)
%  plotParamVariance(Vtheta,ThetaName,ThetaType)
% Plot utility for local sensitivity analysis (see
% @computeParamSensitivity). Plots parameters variance and precision.
%Inputs:
% Vtheta: matrix, parameter covariance matrix from sensitivity analysis
% ThetaName: cell array of strings, parameter names
% ThetaType: cell array of strings, parameter file identifier (A,C,M)
%%
[VSort,idxS]=sort(abs(Vtheta));

for i=1:length(ThetaName)
    ThetaName{i}=[ThetaName{i}, '(',ThetaType{i},')'];
end

subplot(2,1,1)
bar(abs(VSort))
grid on
ax=gca;
ax.XTick=[1:length(Vtheta)];
ax.XLim=[0 length(Vtheta)+1];
ax.XTickLabel=ThetaName(idxS);
ax.XTickLabelRotation=60;
title('Parameter Variance via Linearized Sensitivity')

subplot(2,1,2)
bar(abs(1./VSort))
grid on
ax=gca;
ax.XTick=[1:length(Vtheta)];
ax.XLim=[0 length(Vtheta)+1];
ax.XTickLabel=ThetaName(idxS);
ax.XTickLabelRotation=60;
title('Parameter Precision via Linearized Sensitivity')


end

