clear all
% close all
clc


%% run from config

[PathStruct,MainFolder] = setPaths('giek','.\configA123')

%%
% addpath(genpath(MainFolder))
% cd(MainFolder)
%% plot real data for comparison

a123=load('TestDataA123longDischarge.txt');
% a123=load('TestDataMPET_Discharge.txt');

figure(1)
hold on
plot(a123(:,1),a123(:,2),':k','LineWidth',2)
grid on


%% run
clearOutputFolder=1;
verbose=1;
timeout=5;
[status] = runMPET(PathStruct,clearOutputFolder,verbose);

if status==0
    %% read results and plot
    
    [t,V,I,status,ffrac_c] = readDischargeCurve(PathStruct);
    
    figure(1)
    hold on
    plot(t,V,'LineWidth',2)
    grid on
    xlabel('t [s]')
    ylabel('V [V]')
    legend('A123','MPET')
    
    figure(2)
    hold on
    plot(t,I,'LineWidth',2)
    grid on
    xlabel('t [s]')
    ylabel('I [C rate]')
    legend('A123','MPET')
    %% save discharge data
    
%     [t_unique,idxs]=unique(t);
%     data=[t_unique,V(idxs),I(idxs)];
% 
%     fname=['TestDataMPET_Discharge.txt']
%     save(fname,'data','-ascii','-double')
    
end

