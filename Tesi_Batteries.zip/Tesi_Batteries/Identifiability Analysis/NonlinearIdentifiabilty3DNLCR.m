clear all
close all
clc

user='giek'
%% script options

parallelizza=true;
poolsize=4;

alfa=0.05;
Npoints_a=20;
Npoints_b=20;
Npoints_c=20;

satPlot=1;
colorscale='log';

%% paths

[PathStruct,MainFolder] = setPaths(user,'./configA123');
[PathStruct] = createTmpConfigFolder(PathStruct);

addpath(genpath(MainFolder))
cd(MainFolder)

rmpath(genpath(PathStruct.historyFolder))
%% load discharge data

dataIn=load('TestDataMPET_DischargeNoise.txt');
timeIn=dataIn(:,1);
YIn=dataIn(:,2);
IdischIn=dataIn(:,3);

figure(1001)
plotDischardgeData(YIn,IdischIn,timeIn,[],[])


%% set params initial guesses

run setGroundTruthAndBounds_NLCR_detailRegions.m

%% set noise params

%noise info
sigmaNoise=0.01;

%% setup parallel computations
if parallelizza
    delete(gcp('nocreate'))
    myCluster = parcluster('local');
    parpool(poolsize);
    [poolsize] = createParallelConfigFolders(PathStruct);
else
    poolsize=1;
end
%% grid options

idxA=1;
idxB=2;
idxC=3;


%% from grid values

fname=['NLCR_',ThetaName{idxA},ThetaType{idxA},'_',ThetaName{idxB},ThetaType{idxB},...
    '_',ThetaName{idxC},ThetaType{idxC}]

a=linspace(LogThetaLB(idxA),LogThetaUB(idxA),Npoints_a);
b=linspace(LogThetaLB(idxB),LogThetaUB(idxB),Npoints_b);
c=linspace(LogThetaLB(idxC),LogThetaUB(idxC),Npoints_c);
[GridStruct.A,GridStruct.B,GridStruct.C] = meshgrid(a,b,c);

[LogThetaLB(idxA),LogThetaUB(idxA),Npoints_a]
[LogThetaLB(idxB),LogThetaUB(idxB),Npoints_b]
[LogThetaLB(idxC),LogThetaUB(idxC),Npoints_c]
keyboard


DataStruct.Y=YIn;
DataStruct.time=timeIn;
DataStruct.sigmaNoise=sigmaNoise;

ParStruct.LogThetaStar=LogThetaStar;
ParStruct.LogThetaTest=LogThetaStar;
ParStruct.ThetaName=ThetaName;
ParStruct.ThetaType=ThetaType;


[CHIsqDiff] = nonlinConfRegion3D(DataStruct,ParStruct,PathStruct,GridStruct,idxA,idxB,idxC);

%% plot and save results

save(fname)

close all

try
    figure()
    plotConfRegion3D(GridStruct,ParStruct,idxA,idxB,idxC,CHIsqDiff,alfa,1:5:Npoints_c,1)
    savefig(fname)
catch
end