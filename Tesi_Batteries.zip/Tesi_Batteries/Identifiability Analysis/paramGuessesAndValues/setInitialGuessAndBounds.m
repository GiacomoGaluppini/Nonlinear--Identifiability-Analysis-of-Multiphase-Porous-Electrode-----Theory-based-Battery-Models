%% set params initial guesses

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% BV %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%anode graphite1param
Theta0=[ 3.0e+1 5e-3];
ThetaName={'k0','Rfilm'};
ThetaType={'A','A'};

%cathode LFP
Theta0=[Theta0  1.6e-1 5e-3];
ThetaName={ThetaName{:},'k0','Rfilm'};
ThetaType={ThetaType{:},'C','C'};

%porosity
Theta0=[Theta0 0.414 0.562 0.4];
ThetaName={ThetaName{:},'poros_a','poros_c','poros_s'};
ThetaType={ThetaType{:},'M','M','M'};

%Bruggeman
Theta0=[Theta0 0.5 0.5 0.5];
ThetaName={ThetaName{:},'BruggExp_a','BruggExp_c','BruggExp_s'};
ThetaType={ThetaType{:},'M','M','M'};


%BV
%anode graphite1param
Theta0=[Theta0 1e-6 1e-6 1e-1 1e-6 1e-8];
ThetaName={ThetaName{:},'mean_a','stddev_a','sigma_s_a','G_mean_a','G_stdddev_a'};
ThetaType={ThetaType{:},'M','M','M','M','M'};

%cathode LFP
Theta0=[Theta0 1e-7 1e-7 1e-1 1e-6 1e-8];
ThetaName={ThetaName{:},'mean_c','stddev_c','sigma_s_c','G_mean_c','G_stdddev_c'};
ThetaType={ThetaType{:},'M','M','M','M','M'};

Theta0=[Theta0 2.2e-10 2.94e-10];
ThetaName={ThetaName{:},'Dp','Dm'};
ThetaType={ThetaType{:},'M','M'};



% %% CHEM POT PARAMS

%anode graphite1param
Theta0=[Theta0 1.3992e-20 5.761532e-21];
ThetaName={ThetaName{:},'Omega_a','Omega_b'};
ThetaType={ThetaType{:},'A','A'};

% 
% %cathode LFP
% Theta0=[Theta0   1.8560e-20 5.0148e-10 0.1916e9];
% ThetaName={ThetaName{:},'Omega_a','kappa','B'};
% ThetaType={ThetaType{:},'C','C','C'};


%% set default bounds
ThetaLB=Theta0/10;
ThetaUB=Theta0*10;



%k0 bounds
k0g=1;
k0lfp=3;
ThetaLB(k0g)=1e-0;
ThetaUB(k0g)=1e3;
ThetaLB(k0lfp)=1e-2;
ThetaUB(k0lfp)=1e2;

%Rfilms
Rflms=[2 4];
ThetaLB(Rflms)=ones(size(Rflms))*1e-5;
ThetaUB(Rflms)=ones(size(Rflms))*1e-2;

%Porosities
bexp=[5 6 7];
ThetaLB(bexp)=ones(size(bexp))*0.3;
ThetaUB(bexp)=ones(size(bexp))*0.65;

%Bruggeman
bexp=[ 8 9 10];
ThetaLB(bexp)=ones(size(bexp))*0.5;
ThetaUB(bexp)=ones(size(bexp))*4;

%PSD
psd=[11 12 16 17];
ThetaLB(psd)=ones(size(psd))*1e-8;
ThetaUB(psd)=ones(size(psd))*1e-4;


%Bulk conducts
bulkC=[13 18];
ThetaLB(bulkC)=ones(size(bulkC))*1e-2;
ThetaUB(bulkC)=ones(size(bulkC))*10;


%PCD
pcd=[14 15 19 20];
ThetaLB(pcd)=ones(size(pcd))*1e-9;
ThetaUB(pcd)=ones(size(pcd))*1e-5;


%apply log
LogTheta0=logTransf(Theta0);
LogThetaLB=logTransf(ThetaLB);
LogThetaUB=logTransf(ThetaUB);


