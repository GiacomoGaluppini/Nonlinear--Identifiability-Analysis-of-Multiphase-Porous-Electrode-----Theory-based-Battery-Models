%% set params ground truth 


%anode graphite1param
ThetaStar=[3.338e-21 9.1355e-21 4.0e-7 1.25e-12 123.9507 0.0095914];
ThetaName={'Omega_a','Omega_b','kappa','D','k0','Rfilm'};
ThetaType={'A','A','A','A','A','A'};

%cathode LFP
ThetaStar=[ThetaStar 1.8560e-20 5.0148e-10 0.1916e9 5.3e-19 0.2929 0.0099563];
ThetaName={ThetaName{:},'Omega_a','kappa','B','D','k0','Rfilm'};
ThetaType={ThetaType{:},'C','C','C','C','C','C'};


ThetaStar=[ThetaStar 3.3975e-10 2.9385e-09];
ThetaName={ThetaName{:},'Dp','Dm'};
ThetaType={ThetaType{:},'M','M'};



%% set default bounds
ThetaLB=ThetaStar/10;
ThetaUB=ThetaStar*10;



%k0 bounds
k0g=5;
k0lfp=11;
ThetaLB(k0g)=1e-0;
ThetaUB(k0g)=1e3;
ThetaLB(k0lfp)=1e-2;
ThetaUB(k0lfp)=1e2;

%Rfilms
Rflms=[6 12];
ThetaLB(Rflms)=ones(size(Rflms))*1e-5;
ThetaUB(Rflms)=ones(size(Rflms))*1e-2;

%Ds
Ds=[4 10];
ThetaLB(Ds)=ones(size(Ds))*1e-20;
ThetaUB(Ds)=ones(size(Ds))*1e-10;

%De
De=[13 14];
ThetaLB(De)=ones(size(De))*1e-11;
ThetaUB(De)=ones(size(De))*1e-8;


%% relax bounds a bit
ThetaLB=ThetaLB/2;
ThetaUB=ThetaUB*2;

%% detail bounds (2D or 3D)

%Omega_a	A
ThetaLB(1)=3.16E-22;
ThetaUB(1)=1.00E-20;

%Omega_b'	A'
ThetaLB(2)=3.16E-20;
ThetaUB(2)=3.16E-21;

%k0'	A'
ThetaLB(5)=80;
ThetaUB(5)=200;

%Rfilm'	A'
ThetaLB(6)=0.008912509;
ThetaUB(6)=0.011220185;

%Omega_a'	C'
ThetaLB(7)=1.78E-20;
ThetaUB(7)=2.00E-20;

%kappa'	C'
ThetaLB(8)=1E-10;
ThetaUB(8)=3.16E-09;

%k0'	C'
ThetaLB(11)=0.1;
ThetaUB(11)=1;

%Dp'	M'
ThetaLB(13)=3.16E-10;
ThetaUB(13)=3.55E-10;
%% apply log
LogThetaStar=logTransf(ThetaStar);
LogThetaLB=logTransf(ThetaLB);
LogThetaUB=logTransf(ThetaUB);

