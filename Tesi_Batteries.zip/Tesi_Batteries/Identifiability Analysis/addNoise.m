clear all
close all
clc

%%

in=load('TestDataMPET_Discharge.txt');

media=0;
stddev=1e-2;
rumore=media + stddev.*randn(size(in(:,2)));

out=in;
out(:,2)=out(:,2)+rumore;

plot(in(:,2))
hold on
plot(out(:,2))

fname=['TestDataMPET_DischargeNoise.txt']
save(fname,'out','-ascii','-double')