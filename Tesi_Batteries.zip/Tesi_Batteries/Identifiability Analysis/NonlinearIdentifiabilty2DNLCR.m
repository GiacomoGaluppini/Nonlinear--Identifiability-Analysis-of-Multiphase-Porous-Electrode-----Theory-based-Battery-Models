clear all
close all
clc

user='giek'
%% script options

parallelizza=true;
poolsize=4;

alfa=0.05;
Npoints_a=60;
Npoints_b=15;

satPlot=1;
colorscale='log';

%% paths

[PathStruct,MainFolder] = setPaths(user,'./configA123');
[PathStruct] = createTmpConfigFolder(PathStruct);

addpath(genpath(MainFolder))
cd(MainFolder)

rmpath(genpath(PathStruct.historyFolder))
%% load discharge data

dataIn=load('TestDataMPET_DischargeNoise.txt');
timeIn=dataIn(:,1);
YIn=dataIn(:,2);
IdischIn=dataIn(:,3);

figure(1001)
plotDischardgeData(YIn,IdischIn,timeIn,[],[])


%% set params initial guesses

run setGroundTruthAndBounds_NLCR_detailRegions.m


%% set noise params

%noise info
sigmaNoise=0.01;

%% setup parallel computations
if parallelizza
    delete(gcp('nocreate'))
    myCluster = parcluster('local');
    parpool(poolsize);
    [poolsize] = createParallelConfigFolders(PathStruct);
else
    poolsize=1;
end

%% grid options


switch user
    case 'tower'
        idx1start=7;
        idx1end=length(ThetaName)-1;
    case 'braatz'
        idx1start=2;
        idx1end=6;
    case 'cogswell'
        idx1start=1;
        idx1end=1;
    otherwise
        idx1start=length(ThetaName)-1;
        idx1end=length(ThetaName)-1;
end


for idxA=idx1start:idx1end
    for idxB=idxA+1:length(ThetaName)
        %% from grid values
        fname=['NLCR_',ThetaName{idxA},ThetaType{idxA},'_',ThetaName{idxB},ThetaType{idxB}]
 
        a=linspace(LogThetaLB(idxA),LogThetaUB(idxA),Npoints_a);
        b=linspace(LogThetaLB(idxB),LogThetaUB(idxB),Npoints_b);
        [GridStruct.A,GridStruct.B] = meshgrid(a,b);
        
          
        [LogThetaLB(idxA),LogThetaUB(idxA),Npoints_a]
        [LogThetaLB(idxB),LogThetaUB(idxB),Npoints_b]
%         keyboard
        
        
        DataStruct.Y=YIn;
        DataStruct.time=timeIn;
        DataStruct.sigmaNoise=sigmaNoise;
        
        ParStruct.LogThetaStar=LogThetaStar;
        ParStruct.LogThetaTest=LogThetaStar;
        ParStruct.ThetaName=ThetaName;
        ParStruct.ThetaType=ThetaType;
        
        
        [CHIsqDiff] = nonlinConfRegion2D(DataStruct,ParStruct,PathStruct,GridStruct,idxA,idxB);
        %% plot and save results
        
        
        save(fname)
        
        close all
        
        try
        figure()
        plotConfRegion2D(GridStruct,ParStruct,idxA,idxB,CHIsqDiff,alfa,satPlot,colorscale)
        savefig(fname)
        catch
        end
        
    end
end