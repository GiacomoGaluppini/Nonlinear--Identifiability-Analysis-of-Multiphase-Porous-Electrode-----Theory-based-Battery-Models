function [LogTheta] = logTransf(Theta)
% [LogTheta] = logTransf(Theta)
%  Apply BASE 10 logarithmic tranformation to parameters 
% Inputs:
% Theta: array, param values
% Outputs:
% LogTheta: array, log transformed param values
%%
LogTheta=log10(Theta);
end

