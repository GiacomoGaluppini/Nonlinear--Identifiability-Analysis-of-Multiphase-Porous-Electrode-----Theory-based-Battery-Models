function [Yhat,time] = evalYhat(PathStruct,ThetaVal,ThetaName,ThetaType,time,varargin)
% [Yhat] = evalYhat(PathStruct,ThetaVal,ThetaName,ThetaType,time)
% Evaluate mpet model output (voltage from general data) using a specific parameter set 
% Inputs:
% PathStruct: struct. with required paths to python, mpetrun and mpetplot,
% as well as paths to configuration folders and configuration filenames (see @setPaths)
% ThetaVal: array,  parameter values
% ThetaName: cell array of strings, parameter names
% ThetaType: cell array of strings, parameter file identifier (A,C,M)
% time: array, voltage data timestamps
% Outputs:
% Yhat: array, model predicted discharge voltage
%%
if isempty(varargin)
    opt.clearOutputFolder=1;
    opt.timeout=10*60;
    opt.verbose=0;
else
    opt=varargin{1};
end
%%
if ~isempty(ThetaVal)
    %create param structure with new values
    [ThetaStruct] = createParamStruct(ThetaVal,ThetaName,ThetaType);
    
    % set main params at on configuration files
    setConfigurationFiles(PathStruct,ThetaStruct);
end

%run mpet with updated params

runMPET(PathStruct,opt.clearOutputFolder,opt.verbose,opt.timeout);

[t,V,~,status] = readDischargeCurve(PathStruct);
if status==0
    %interpolate at given times
    if ~isempty(time)
        [t2,idx] = unique(t);
        V2=V(idx);
        time=time-time(1);
        Yhat = interp1(t2,V2,time,'linear','extrap');
    else
        Yhat=V;
        time=t;
    end
else
    Yhat=nan(size(time));
end
end

