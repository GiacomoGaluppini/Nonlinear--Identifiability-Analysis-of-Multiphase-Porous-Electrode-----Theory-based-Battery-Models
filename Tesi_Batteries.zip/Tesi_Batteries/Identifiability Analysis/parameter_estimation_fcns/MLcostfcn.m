function [minusLoglike,Yhat,wasnan] = MLcostfcn(Y,LogTheta,ThetaName,ThetaType,PathStruct,time,sigmaNoise)
%[minusLoglike,Yhat,wasnan] = MLcostfcn(Y,LogTheta,ThetaName,ThetaType,PathStruct,time,sigmaNoise)
% Compute negative Log-Likelihood function assuming Gaussian Distributions
% Inputs:
% Y: array, voltage data 
% LogTheta: array, log transoformed (see @logTranfs) parameter values
% ThetaName: cell array of strings, parameter names
% ThetaType: cell array of strings, parameter file identifier (A,C,M)
% PathStruct: struct. with reuired paths to python, mpetrun and mpetplot,
% as well as paths to configuration folders and configuration filenames (see @setPaths)
% time: array, voltage data timestamps
% sigmaNoise: scalar, std deviation of measurement noise
% Outputs:
% minusLoglike: scalar, negative Log-Likelihood
% Yhat: array, model predicted discharge voltage
% wasnan: bool, true/1 if Yhat anly contains nans
%%
[ParPathStruct,w_id] = setParallelPathStruct(PathStruct);

[Yhat] = evalYhat(ParPathStruct,invLogTransf(LogTheta),ThetaName,ThetaType,time);

if sum(isnan(Yhat))==length(Yhat)
    minusLoglike=1e20;
    wasnan=1;
else
    residual=Y-Yhat;
    minusLoglike=sum(residual.^2)./(sigmaNoise.^2);
    wasnan=0;
end

if isempty(w_id)
    figure(9999)
    comparePlot(time,Y,Yhat)
    title(['Loglike= ',num2str(-minusLoglike)])
    drawnow
end
end

