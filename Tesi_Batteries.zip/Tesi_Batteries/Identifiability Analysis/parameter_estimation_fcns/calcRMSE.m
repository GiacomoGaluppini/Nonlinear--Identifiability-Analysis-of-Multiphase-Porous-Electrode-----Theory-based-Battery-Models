function rmse = calcRMSE(data,predictions)
%calcRMSE(data,predictions) 
%RMSE gof metric computation
%Input:
%data: vector of data
%predictions: vector of model predictions
%Ouput:
% rmse: RMSE gof metric
%%
    rmse = sqrt(mean((data - predictions).^2));
end

