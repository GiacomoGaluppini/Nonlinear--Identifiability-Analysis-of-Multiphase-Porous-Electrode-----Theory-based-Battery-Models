function [R2,SSR,TSS] = calcR2(data,predictions)
%calcR2(data,predictions) 
%R^2 gof metric computation
%Input:
%data: vector of data
%predictions: vector of model predictions
%Ouput:
% R2: R^2 gof metric
%%

residui=data-predictions;
idx=find(~isnan(residui));

SSR=sum(residui(idx).^2);

%%
residui=data-mean(data);
idx=find(~isnan(residui));

TSS=sum(residui(idx).^2);

%%

R2=1-SSR/TSS;
end

