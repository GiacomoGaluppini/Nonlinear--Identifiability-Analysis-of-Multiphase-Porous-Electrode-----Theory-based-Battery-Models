function [Theta] = invLogTransf(LogTheta)
% [Theta] = invLogTransf(LogTheta)
%  Revert BASE 10 logarithmic tranformation to parameters 
% Inputs:
% Theta: array, log transformed param values
% Outputs:
% Theta: array, original param values
%%
Theta=10.^(LogTheta);
end

