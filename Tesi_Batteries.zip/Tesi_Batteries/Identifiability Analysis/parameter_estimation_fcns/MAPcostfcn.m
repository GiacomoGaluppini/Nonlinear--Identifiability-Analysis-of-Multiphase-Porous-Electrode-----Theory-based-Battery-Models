function [minusMAP,Yhat,wasnan] = MAPcostfcn(Y,LogTheta,ThetaName,ThetaType,PathStruct,time,sigmaNoise,muPrior,sigmaPrior)
%[minusMAP,Yhat,wasnan] = MAPcostfcn(Y,LogTheta,ThetaName,ThetaType,PathStruct,time,sigmaNoise,muPrior,sigmaPrior)
% Compute Negative Log Maximum A-Posteriori assuming Gaussian Distributions
% Inputs:
% Y: array, voltage data 
% LogTheta: array, log transoformed (see @logTranfs) parameter values
% ThetaName: cell array of strings, parameter names
% ThetaType: cell array of strings, parameter file identifier (A,C,M)
% PathStruct: struct. with reuired paths to python, mpetrun and mpetplot,
% as well as paths to configuration folders and configuration filenames (see @setPaths)
% time: array, voltage data timestamps
% sigmaNoise: scalar, std deviation of measurement noise
% muPrior: array, means of prior parameter distribution
% sigmaPrior: array, std devs of prior parameter distribution
% Outputs:
% minusMAP: scalar, Negative Log Maximum A-Posteriori
% Yhat: array, model predicted discharge voltage
% wasnan: bool, true/1 if Yhat anly contains nans
%%
[ParPathStruct,w_id] = setParallelPathStruct(PathStruct);

[Yhat] = evalYhat(ParPathStruct,invLogTransf(LogTheta),ThetaName,ThetaType,time);

if sum(isnan(Yhat))==length(Yhat)
    minusMAP=1e20;
    wasnan=1;
else
    residual=Y-Yhat;
    minusLogLike=sum(residual.^2./(sigmaNoise.^2));
    
    PriorTerm = PRIORcostfcn(LogTheta,muPrior,sigmaPrior);
    
    minusMAP=minusLogLike+PriorTerm;
    
    wasnan=0;
end

if isempty(w_id)
    figure(9999)
comparePlot(time,Y,Yhat)
title(['MAP= ',num2str(-minusMAP)])
drawnow
end

end

