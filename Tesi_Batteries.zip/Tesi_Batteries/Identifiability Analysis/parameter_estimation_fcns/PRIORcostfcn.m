function [Prior] = PRIORcostfcn(LogTheta,muPrior,sigmaPrior)
%[Prior] = PRIORcostfcn(Theta,muPrior,sigmaPrior)
% Compute Prior Cost assuming Gaussian Distributions
% Inputs:
% LogTheta: array, log transoformed (see @logTranfs) parameter values
% muPrior: array, means of prior parameter distribution
% sigmaPrior: array, std devs of prior parameter distribution
% Outputs:
% Prior: scalar, Prior Cost
%%
Prior=sum(((LogTheta-muPrior)./sigmaPrior).^2);
end

