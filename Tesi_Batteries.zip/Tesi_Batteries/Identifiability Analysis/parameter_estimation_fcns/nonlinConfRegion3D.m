function [CHIsqDiff] = nonlinConfRegion3D(DataStruct,ParStruct,PathStruct,GridStruct,idxA,idxB,idxC)
% [CHIsqDiff] = nonlinConfRegion3D(DataStruct,ParStruct,PathStruct,GridStruct,idxA,idxB,idxC)
% compute 3-dimensional nonlinear confidence region with chi-squared
% statistics 
% Inputs:
% DataStruct: struct, with fields:
%         DataStruct.Y; -> array, voltage data points
%         DataStruct.time; -> array, timestamps
%         DataStruct.sigmaNoise; -> scalar, measurement noise std dev
% ParamStruct: struct, with fields:
%         ParStruct.LogThetaStar;-> array, Ground Truth param values, log
%         transformed (see @logTransf)
%         ParStruct.LogThetaTest;-> array, Baseline  param values, log
%         transformed (see @logTransf)
%         ParStruct.ThetaName;-> cell array, see @createParamStruct
%         ParStruct.ThetaType;-> cell array, see @createParamStruct
% PathStruct: struct, with required paths to python, mpetrun and mpetplot,
% as well as paths to configuration folders and configuration filenames (see @setPaths)
% GridStruct: struct, with fields [GridStruct.A,GridStruct.B
% ,GridStruct.C], as outputs from @meshgrid. See the example at the end of
% help.
% idxA: scalar, index of first parameter to be examined
% idxB: scalar, index of second parameter to be examined
% idxB: scalar, index of third parameter to be examined
% Outputs:
% CHIsqDiff: matrix, difference of chi-squared values between test points
% and ground truth point
% 
% 
%Example for GridStruct creation:
% 
% a=linspace(LogThetaLB(idxA),LogThetaUB(idxA),Npoints_a);
% b=linspace(LogThetaLB(idxB),LogThetaUB(idxB),Npoints_b);
% c=linspace(LogThetaLB(idxC),LogThetaUB(idxC),Npoints_c);
% [GridStruct.A,GridStruct.B,GridStruct.C] = meshgrid(a,b,c);
% 
% 
%%
Y=DataStruct.Y;
time=DataStruct.time;
sigmaNoise=DataStruct.sigmaNoise;

A=GridStruct.A;
B=GridStruct.B;
C=GridStruct.C;

LogThetaStar=ParStruct.LogThetaStar;
LogThetaTest=ParStruct.LogThetaTest;
ThetaName=ParStruct.ThetaName;
ThetaType=ParStruct.ThetaType;

%%

CHIsqStar=MLcostfcn(Y,LogThetaStar,ThetaName,ThetaType,PathStruct,time,sigmaNoise);

CHIsqDiff = nan(size(A));
LogThetaTestGrid = cell(size(A));

for i=1:size(CHIsqDiff,1)
    for j=1:size(CHIsqDiff,2)
        parfor k=1:size(CHIsqDiff,3)
            LogThetaTestGrid{i,j,k}=LogThetaTest;
            LogThetaTestGrid{i,j,k}(idxA)=A(i,j,k);
            LogThetaTestGrid{i,j,k}(idxB)=B(i,j,k);
            LogThetaTestGrid{i,j,k}(idxC)=C(i,j,k);
            [CHIsqTest,~,wasnan]=MLcostfcn(Y,LogThetaTestGrid{i,j,k},ThetaName,ThetaType,PathStruct,time,sigmaNoise);
            if ~wasnan
                CHIsqDiff(i,j,k)=CHIsqTest-CHIsqStar;
            end
        end
    end
end

end

