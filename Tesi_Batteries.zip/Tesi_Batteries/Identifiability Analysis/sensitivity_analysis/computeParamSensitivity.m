function [Vtheta,Vtheta_inv,CumSens,Sens,Yhat_plus,wasnan_plus,Yhat_minus,wasnan_minus,H] = computeParamSensitivity(stepPercent,LogTheta0,LogThetaLB,LogThetaUB,ThetaName,ThetaType,PathStruct,time,sigmaNoise)
% [Vtheta,Vtheta_inv,CumSens,Sens,Yhat_plus,wasnan_plus,Yhat_minus,wasnan_minus,H] = computeParamSensitivity(stepPercent,LogTheta0,LogThetaLB,LogThetaUB,ThetaName,ThetaType,PathStruct,time,sigmaNoise)
% Perform local sensitivity analysis about given parameter value (parallel code)
% Inputs:
% stepPercent: scalar, percent step size for finite difference (percent of LogTheta0)
% approximation of derivatives
% LogTheta0: array, log transoformed (see @logTranfs) parameter values
% LogThetaLB: array, log transoformed (see @logTranfs) lower bounds
% LogThetaUB: array, log transoformed (see @logTranfs) upper bounds
% ThetaName: cell array of strings, parameter names
% ThetaType: cell array of strings, parameter file identifier (A,C,M)
% PathStruct: struct. with reuired paths to python, mpetrun and mpetplot,
% as well as paths to configuration folders and configuration filenames (see @setPaths)
% time: array, voltage data timestamps
% sigmaNoise: scalar, std deviation of measurement noise
% Outputs:
% Vtheta: matrix, parameter covariance matrix from sensitivity analysis
% Vtheta_inv: matrix, parameter precision matrix from sensitivity analysis
% CumSens: matrix, cumulative absolute sensitivity
% Sens: matrix, sensitivity
% Yhat_plus: cell array of arrays, model predicted discharge voltage for
% LogTheta0*(1+stepPercent) param values
% wasnan_plus: cell array of bool, true/1 if Yhat anly contains nans for
% each experiment 
% Yhat_minus: cell array of arrays, model predicted discharge voltage for
% LogTheta0*(1-stepPercent) param values
% wasnan_minus: cell array of bool, true/1 if Yhat anly contains nans for each experiment
% H: cell array of dimensional step sizes used for finite difference (percent of LogTheta0)
%%
Yhat_plus=cell(size(LogTheta0));
Yhat_minus=cell(size(LogTheta0));
H=nan(size(LogTheta0));


parfor i=1:length(LogTheta0)
    
    pPlus=LogTheta0;
    pMinus=LogTheta0;
    
    h=LogTheta0(i)*stepPercent;
%     h=abs(LogThetaUB(i)-LogThetaLB(i))*stepPercent;
    pPlus(i)=LogTheta0(i)+h;
    pMinus(i)=LogTheta0(i)-h;
    

   [Yhat_plus{i},wasnan_plus(i)] = internal_evalYhat(pPlus,ThetaName,ThetaType,PathStruct,time,0);
   [Yhat_minus{i},wasnan_minus(i)] = internal_evalYhat(pMinus,ThetaName,ThetaType,PathStruct,time,0);
   H(i)=h;

end

Sens=nan(length(Yhat_plus{1}),length(LogTheta0));
for i=1:length(LogTheta0)
    if ~wasnan_plus(i) && ~wasnan_minus(i)
        Sens(:,i)=(Yhat_plus{i}-Yhat_minus{i})/(2*H(i));
    end
end


Vtheta_inv=zeros(length(LogTheta0),length(LogTheta0));
for j=1:length(Yhat_plus{i})
    Vtheta_inv=Vtheta_inv+((Sens(j,:)'*Sens(j,:))/(sigmaNoise.^2));
end

Vtheta=inv(Vtheta_inv);

CumSens=zeros(1,length(LogTheta0));
for i=1:length(Yhat_plus{1})
    CumSens=CumSens+abs(Sens(i,:));
end



end

function [Yhat,wasnan] = internal_evalYhat(LogTheta,ThetaName,ThetaType,PathStruct,time,lambda)


[ParPathStruct,w_id] = setParallelPathStruct(PathStruct);
    
[Yhat] = evalYhat(ParPathStruct,invLogTransf(LogTheta),ThetaName,ThetaType,time);

if sum(isnan(Yhat))==length(Yhat)

    wasnan=1;
else

    wasnan=0;
end

end

