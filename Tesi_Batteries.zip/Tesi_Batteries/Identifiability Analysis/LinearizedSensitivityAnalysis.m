clear all
close all
clc

%% script options

parallelizza=true;

%% paths

[PathStruct,MainFolder] = setPaths('giek','./configA123');
[PathStruct] = createTmpConfigFolder(PathStruct);

addpath(genpath(MainFolder))
cd(MainFolder)

rmpath(genpath(PathStruct.historyFolder))

%% load discharge data

dataIn=load('TestDataMPET_DischargeNoise.txt');
timeIn=dataIn(:,1);
YIn=dataIn(:,2);
IdischIn=dataIn(:,3);

figure(1001)
plotDischardgeData(YIn,IdischIn,timeIn,[],[])

sigmaNoise=0.01;
%% set params initial guesses

run setGroundTruthAndBounds_NLCR

%% setup parallel computations
if parallelizza
delete(gcp('nocreate'))
myCluster = parcluster('local');
parpool(myCluster.NumWorkers);
[poolsize] = createParallelConfigFolders(PathStruct);
else
    poolsize=1;
end

%% local, central finite difference sensitivity analysis
stepPercent=10e-3;
[Vtheta,Vtheta_inv,CumSens,Sens,Yhat_plus,wasnan_plus,Yhat_minus,wasnan_minus,H] = computeParamSensitivity(stepPercent,LogThetaStar,LogThetaLB,LogThetaUB,ThetaName,ThetaType,PathStruct,timeIn,sigmaNoise);
save(['LinearizedSensitivityAnalysis_',strrep(num2str(100*stepPercent),'.',''),'percentStep.mat'])
